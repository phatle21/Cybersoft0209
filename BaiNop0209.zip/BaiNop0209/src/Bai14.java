import java.util.ArrayList;
import java.util.Scanner;

public class Bai14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		ArrayList<Integer> array = new ArrayList<>();
		
		System.out.println("Nhập số phần tử: ");
		int m = sc.nextInt();
		
		while(m < 2) {
			System.out.println("Vui lòng nhập số phần tử từ 2 trở lên: ");
			m = sc.nextInt();
		}
		
		for(int i = 0 ; i < m ; i++) {
			System.out.print("Phần tử thứ " + i + " : ");
			int n = sc.nextInt();
			array.add(n); // add các số n vào arraylist
		}
		// thêm các phần tử của array vào arrTemp
	    // nếu trong arrTemp đã tồn tại phần tử giống trong array
	    // thì không thêm vào, ngược lại thêm bình thường
		ArrayList<Integer> arrTemp = new ArrayList<>();
		for(int i = 0 ; i < array.size() ; i++) {
			if(!arrTemp.contains(array.get(i))) {
				arrTemp.add(array.get(i));
			}
		}
		// xóa các phần tử của mảng
		array.clear();
		array.addAll(arrTemp); // cập nhật 
		System.out.println("Mảng sau khi các phần tử trùng bị loại bỏ : " + array);
	}

}
