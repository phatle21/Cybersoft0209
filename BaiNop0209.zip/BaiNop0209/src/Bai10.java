import java.util.Scanner;

public class Bai10 {
	
	public static boolean isPrime(int n) {
		// số nguyên tố là 1 và chính nó
		if(n < 2) {
			return false;
		}
		for(int i = 2 ; i < ( n - 1 ) ; i++) {
			if(n % i == 0) {
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập số N : ");
		int n = sc.nextInt();
		while(n < 1) {
			System.out.println("Phải nhập từ 1 trở lên , vui lòng nhập lại : ");
			n = sc.nextInt();
		}
		System.out.print("Tổng các số nguyên tố: ");
		for(int i = 1 ; i <= n ; i++) {
			if(isPrime(i)) {
				System.out.print(i + " ");
			}
		}
	}

}
