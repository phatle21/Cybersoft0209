import java.util.Scanner;

public class Bai05 {
		// dùng công thức
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double xA,yA , xB,yB, doDaiAB ;
		Scanner sc = new Scanner(System.in);	
		System.out.println("Nhập xA(hoành độ điểm A) : ");
		xA = sc.nextDouble();

		System.out.println("Nhập yA(tung độ điểm A) : ");
		yA = sc.nextDouble();
		System.out.println("Nhập xB(hoành độ điểm B) : ");
		xB = sc.nextDouble();
		System.out.println("Nhập yB(tung độ điểm B) : ");
		yB = sc.nextDouble();

		doDaiAB = Math.sqrt(Math.pow((xB - xA), 2) + Math.pow((yB - yA), 2));
		System.out.println("Độ dài đoạn thẳng AB = "+ doDaiAB);
	}

}
