import java.util.Scanner;

public class Bai06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Chuỗi nhập: ");
		String str = sc.nextLine();
		while(str.equals("")) {
			System.out.println("Chưa nhập chuỗi , vui lòng nhập lại : ");
			str = sc.nextLine();
		}
		String[] words = str.split(" "); // chia nhỏ thành các chuỗi con
        String reversedString = "";
        // đảo ngược chuỗi con bằng vòng lặp for
		for(int i = 0 ; i < words.length ; i++) {
			String word = words[i];
            String reverseWord = "";
            for (int j = word.length()-1; j >= 0; j--)
            {
                reverseWord = reverseWord + word.charAt(j);
            }
            reversedString = reversedString + reverseWord + " ";
		}
		System.out.println("Chuỗi đảo ngược: " + reversedString);
	}

}
