import java.util.Scanner;

public class Bai16 {
	
	// công thức
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập năm: ");
		int year = sc.nextInt();
		if(year % 100 == 0) {
			if(year % 400 ==0) {
				System.out.println("Là Năm nhuận");
			}else {
				System.out.println("Không là năm nhuận");
			}
		}
		else if(year % 4 == 0) {
			System.out.println("Là năm nhuận");
		}else {
			System.out.println("Không là năm nhuận");
		}
	}

}
