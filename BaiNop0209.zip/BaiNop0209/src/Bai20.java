import java.util.Scanner;

public class Bai20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n;
		do {
			System.out.println("Nhập số phần tử của mảng: ");
			n = sc.nextInt();
		}while(n <= 0);
		int arr[] = new int[n];
		int chan[] = new int[n];
		int le[] = new int[n];
		
		System.out.println("Nhập các phần tử cho mảng: ");
		for(int i = 0 ; i < n ; i++) {
			System.out.println("Phần tử thứ " + i + " : ");
			arr[i] = sc.nextInt();
		}
		// đếm các số chẵn để i chạy
		int c = 0 , l = 0 ;
		for(int i = 0 ; i < n ; i++) {
			if(arr[i] % 2 == 0) {
				chan[c] = arr[i];
				c++;
			}else {
				le[l] = arr[i];
				l++;
			}
		}
		
		System.out.println("Mảng chẵn: ");
		for(int i = 0 ; i < c ; i++) {
			System.out.print(chan[i] + "\t");
		}
		System.out.println("\nMảng lẻ: ");
		for(int i = 0 ; i < l ; i++) {
			System.out.print(le[i] + "\t");
		}
		
	}

}
