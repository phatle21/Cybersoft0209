import java.util.Scanner;

public class Bai09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a,b;
		do {
			System.out.println("Nhập số a: ");
			a = sc.nextInt();
			System.out.println("Nhập số b: ");
			b = sc.nextInt();
		}while(a < 10 || b > 99);
		int x = a % 10; // lấy phần dư của a -> x
		int y = b % 10; // lấy phần dư của b -> y
		a = a / 10; // lấy thương của a -> a
		b = b / 10; // lấy thương của b -> b
		// so sánh
		if (a == y || a == b || x == y || x == b) {
			System.out.println("Đúng");
		}else {
			System.out.println("Sai");
		}			
	}
}
