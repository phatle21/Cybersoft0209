import java.util.Scanner;
import java.lang.String;
public class Bai15 {
	
	// dùng thư viện java.lang.String
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập 1 chuỗi bất kỳ : ");
		String str = sc.nextLine();
		// kiểm tra chuỗ rỗng
		while(str.equals("")) {
			System.out.println("Chuỗi chưa nhập , vui lòng nhập chuỗi : ");
			str = sc.nextLine();
		}
		System.out.println("Độ dài của chuỗi : " + str.length());
		int i;
		do {
			System.out.println("Nhập vị trí ký tự muốn tìm : ");
			i = sc.nextInt();
		}while(i > 0 && i <= str.length());
		
		char ch = str.charAt(i);
		System.out.println("Chuỗi ký tự sau khi nhập vị trí : "+ ch);
		String str1 = "abcdef";
		System.out.println("Có chuỗi con abcdef hay không ??? ");
		if(str.contains(str1)) {
			System.err.println("Có");
		}else {
			System.err.println("Không");
		}
		
	}

}
