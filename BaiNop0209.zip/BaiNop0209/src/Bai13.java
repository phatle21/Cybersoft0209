import java.util.Scanner;

public class Bai13 {
	
	public static void main(String[] args) {
		// bộ test : 2 -8 -2 -3 8
		
		Scanner sc = new Scanner(System.in);
		int n;
		do {
			System.out.print("Nhập vào số phần tử của mảng : ");
			n = sc.nextInt();
		}while(n < 0);
		// khởi tạo , cấp phát bộ nhớ
		int a[] = new int[n];
		System.out.println("Nhập các phần tử cho mảng: ");
		for (int i = 0; i < n; i++) {
	        System.out.print("Nhập phần tử thứ " + i + ": ");
	        a[i] = sc.nextInt();
	    }
		// hiển thị
		System.out.print("\nMảng sau khi nhập: ");
	    for (int i = 0; i < n; i++) {
	        System.out.print(a[i] + " ");
	    }
	    
	    // giá trị trung bình : dùng.length đếm số phần tử
	    double sum = 0,gttb;
	    for(int i = 0 ; i < a.length ; i++) {
	    	sum += a[i];	  	
	    }	    
	    gttb = (sum / a.length); 
	    System.out.println("\nGiá trị trung bình : " + gttb);
	    
	    // Phần tử lớn nhất , nhỏ nhất
	    int min = a[0];
	    int max = a[0];
	    for(int i = 0 ; i < a.length ; i++) {
	    	if(a[i] < min) {
	    		min = a[i];
	    	}
	    	if(a[i] > max) {
	    		max = a[i];
	    	}
	    }
	    System.out.println("Giá trị lớn nhất: " + max);
	    System.out.println("Giá trị nhỏ nhất: "+ min);
	    
	    // Phần tử âm lớn nhất , nhỏ nhất ( kiểm tra < 0 )
	    int amMax = a[0];
	    int amMin = a[0];
	    for(int i = 1 ; i < a.length ; i++) {
	    	if( (a[i] < 0 && amMax >= 0) || (a[i] < 0 && a[i] > amMax)) {
	    		amMax = a[i];
	    	}
	    	if (a[i] < 0 && Math.abs (a[i]) > Math.abs((a[i + 1]))) {
	    		amMin = a[i];
	    	}
	    }
	    System.out.println("Giá trị âm lớn nhất: "+ amMax);
	    System.out.println("Giá trị âm nhỏ nhất: "+ amMin);
	    
	    // Phần tử dương lớn nhất , nhỏ nhất ( kiểm tra > 0 )
	    int dnn = a[0]; 
	    int dln = a[0];
	    for(int i = 0 ; i < a.length ; i++) {
	    	if(a[i] > 0 && a[i] < dnn) {
	    		dnn = a[i];
	    	}
	    	if(a[i] > 0 && a[i] > dln) {
	    		dln = a[i];
	    	}
	    }
	    System.out.println("Giá trị dương lớn nhất: "+ dln);
	    System.out.println("Giá trị dương nhỏ nhất : " + dnn);
	    
	    // Các phần tử chẵn và lẻ ( tách làm 2 mảng : chia hết 2 là chẵn )
	    int chan[] = new int[n];	
	    int le[] = new int[n];
	    int c = 0 , l = 0 ;
	    for(int i = 0 ; i < n ; i++) {
	    	if(a[i] % 2 == 0) {
	    		chan[c] = a[i];
	    		c++;
	    	}else {
	    		le[l] = a[i];
	    		l++;
	    	}
	    }
	    System.out.print("Các phần tử của mảng chẵn là: ");
	    for (int i = 0; i < c; i++) {
	        System.out.print(chan[i] + " ");
	    }
	    System.out.print("\nCác phần tử của mảng lẻ là: ");
	    for (int i = 0; i < l; i++) {
	        System.out.print(le[i] + " ");
	    }
	    
	    // thêm 1 phần tử theo index
	    // dùng mảng phụ
	    System.out.print("\nNhập số cần chèn: ");
	    int value = sc.nextInt();
	    System.out.print("Nhập vị trí cần chèn: ");
	    int position = sc.nextInt();
	    int b[] = new int[n+1]; // copy mảng a từ đầu đến trước biến position
	    for(int i = 0 ; i < position ; i++) {
	    	b[i] = a[i]; // các giá trị đã copy lưu vào mảng b
	    }
	    b[position] = value; // lưu giá trị
	    for(int i = position + 1 ; i < n + 1 ; i++) {
	    	b[i] = a[i-1]; // chèn giá trị cần muốn vào mảng a 
	    }
	    n++; // tăng số phần tử của mảng lên 1 đơn vị
	    a = new int[n]; // trả lại vào mảng
	    System.out.print("Mảng sau khi chèn:  ");
	    for(int i = 0 ; i < n ; i++) {
	    	a[i] = b[i]; // copy mảng b sang mảng a
	    	System.out.print(a[i] + " ");
	    }
 	    
	   // xóa 1 phần tử theo index
	    System.out.print("\nNhập vị trí k cần xóa: ");
	    int k = sc.nextInt();
	    for(int i = k ; i < n - 1 ; i++) {
	    	a[i] = a[i+1]; // cập nhật lại mảng
	    }
	    n--; // hoặc ko n-- thì dưới for là i < n - 1
	    System.out.print("Mảng sau khi xóa: ");
	    for(int i = 0 ; i < n ; i++) {
	    	System.out.print(a[i] + " ");
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
		
	}

}
