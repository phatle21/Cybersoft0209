import java.util.Scanner;

public class Bai08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập chuỗi: ");
		String str = sc.nextLine();
		while(str.equals("")) {
			System.out.println("Chưa nhập chuỗi, vui lòng nhập lại: ");
			str = sc.nextLine();
		}
		// kiểu string thành kiểu mảng char
		char[] charArray = str.toCharArray();
		boolean space = true;
		// duyệt từng ký tự trong mảng char
		for(int i = 0 ; i < charArray.length ; i++) {
			// mảng char là chữ cái
			if(Character.isLetter(charArray[i])) {
				// khoảng trắng trước chữ cái
				if(space) {
					// in hoa
					charArray[i] = Character.toUpperCase(charArray[i]);
					space = false;
				}
			}else {
				space = true;
			}
		}
		// đổi mảng char thành string
		str = String.valueOf(charArray);
		System.out.println("Chuỗi in hoa đầu chữ cái : "+ str);
	}
}
