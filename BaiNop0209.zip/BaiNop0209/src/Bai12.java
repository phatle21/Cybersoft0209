import java.util.Scanner;

public class Bai12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập chiều cao: ");
		int n = sc.nextInt();
		while(n < 1 || n > 9) {
			System.out.println("Chỉ được nhập từ 1 đến 9 , vui lòng nhập lại : ");
			n = sc.nextInt();
		}
		// 2 vòng lặp lồng nhau 
		// for i là từ 1 đến n ( chiều cao tam giác )
		// for j in ra các số và khoảng trắng
		for(int i = 1 ; i <= n ; ++i ) {
			for(int j =  1 ; j <= i ; ++j) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		
	}

}
