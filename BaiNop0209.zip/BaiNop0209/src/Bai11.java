import java.util.Scanner;
import java.lang.Math;
public class Bai11 {
	
	public static double log2(int n) {
	    return Math.log(n) / Math.log(2);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập số tự nhiên N : ");
		int n = sc.nextInt();
		while(n <= 0) {
			System.out.println("Nhập từ 1 trở lên , vui lòng nhập lại : ");
			n = sc.nextInt();
		}
		// dùng thư viên Math
		double log2x = log2(n);
		System.out.println(log2x);
	}

}
