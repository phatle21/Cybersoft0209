import java.util.Random;
import java.util.Scanner;

public class Bai17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int soBan;
		do {
			System.out.print("Mời bạn đoán số (từ 1 đến 1000) : ");
			soBan = sc.nextInt();
		}while(soBan < 1 || soBan > 1000);
		
		Random rd = new Random();
		int soMay = 1 + rd.nextInt(1000); // công thức random
		while(soMay > 0) {
			if(soBan == soMay) {
				System.out.println("Chúc mừng bạn đoán đúng");
				break;
			}else {
				System.out.println("Sai rồi...Mời bạn nhập số lớn hơn hoặc nhỏ hơn");
				soBan = sc.nextInt();	
			}
			
		}
		
	}

}
