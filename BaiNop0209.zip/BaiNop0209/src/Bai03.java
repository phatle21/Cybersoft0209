import java.io.File;
import java.util.Properties;

public class Bai03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Version
	    System.out.println("Java Version: "+System.getProperty("java.specification.version"));
		// Runtime Version
		System.out.println("Java Runtime Version: "+ System.getProperty("java.version"));

		Properties prop = System.getProperties();
		// Home ???
		System.out.println("Home: "+ prop.getProperty("java.home"));
		// Vendor
		System.out.println("JVM Vendor: "+ prop.getProperty("java.vendor"));
		// Vendor URL
		System.out.println("JVM Vendor URL: "+ prop.getProperty("java.vendor.url"));
	     // ClassPath
		 String absolutePath = new File(".").getAbsolutePath();
	     System.out.println(absolutePath);
	}

}
