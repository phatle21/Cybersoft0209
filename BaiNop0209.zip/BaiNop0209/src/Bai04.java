import java.util.Scanner;

public class Bai04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,a;
		int sum = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập vào số nguyên: ");
		n = sc.nextInt();
		while( n <= 0 ) {
			System.out.println("Nhập sai . Nhập lại: ");
			n = sc.nextInt();
		}
		// lấy phần dư ( số cuối ) lưu vào a và + với sum , 
		//sau đó thương dùng để lấy phần dư tiếp
		// vòng lặp sẽ chạy đến khi thương được chia hết
		while( n > 0 ) {
			a = n % 10;
			sum = sum + a;
			n = n / 10;
		}
		System.out.println("Tổng các chữ số: " + sum);
	}

}
