import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;

public class Bai19 {
	// nhập số khác , làm sao để quay nhập lại
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("*** Chương trình giải phương trình ***");
		System.out.println("1. Phương trình bậc nhất");
		System.out.println("2. Phương trình bậc hai");
		System.out.println("----  Mời bạn chọn  ----");
		Scanner sc = new Scanner(System.in);		
		int luaChon = sc.nextInt();
		double a,b,c,delta,nghiem;
		// làm tròn 2 chữ số thập phân
		DecimalFormat decimalFormat = new DecimalFormat("#.##"); 
		
		switch(luaChon) {
		case 1:
			System.out.println("Bạn đã chọn phương trình bậc nhất");
			System.out.println("Nhập số a: ");
			a = sc.nextDouble();
			System.out.println("Nhập số b: ");
			b = sc.nextDouble();
			System.out.println("Phương trình bậc nhất: " + a + "x + "+ b + " = 0 ");
			if(a == 0) {
				if(b == 0) {
					System.out.println("Phương trình vô số nghiệm");
				}else {
					System.out.println("Phương trình vô nghiệm");
				}
			}else {
				nghiem = (double) -b/a;
				System.out.println("Phương trình có nghiệm x = " + decimalFormat.format(nghiem));
			}
			break;
		case 2:
			System.out.println("Bạn đã chọn phương trình bậc hai");
			do {
				System.out.println("Nhập a # 0 : ");
				a = sc.nextDouble();
			}while( a == 0 );
			System.out.println("Nhập b: ");
			b = sc.nextDouble();
			System.out.println("Nhập c: ");
			c = sc.nextDouble();
			System.out.println("Phương trình bậc hai: " + a + "x^2 + " + b + "x + " + c + " = 0");
			delta = Math.pow(b, 2) - 4 * a * c;
			if(delta < 0) {
				System.out.println("Phương trình vô nghiệm");
			}else if(delta == 0) {
				System.out.println("Phương trình nghiệm kép x1 = x2 = " + (-b/(2*a)));
			}else {
				double x1 = (-b + Math.sqrt(delta)) / (2 * a);
	            double x2 = (-b - Math.sqrt(delta)) / (2 * a);
	            System.out.println("Phương trình có 2 nghiệm x1 = " + x1 + " và x2 = " + x2);
			}
			break;
			default: 
				System.out.println("Chỉ được nhập 1 hoặc 2 , hãy chạy lại chương trình");			
		}
	}

}
