import java.util.Scanner;

public class Bai02 {
	
	// chuyển về nhị phân
	// lấy phần dư % 2 rồi lưu vào mảng
	// trong mảng lấy số cuối cùng ( i-- ) -> ra nhị phân
	public void convertBinary(int n) {
		int arr[] = new int[40];
		int i = 0;
		while( n > 0) {
			arr[i++] = n % 2 ; // 19 => a[0,1,2,3,4] = 1,1,0,0,1
			// a[0] = 1 ;; a[1] = 1
			n = n / 2;
		}
		// dưới đi lên
		for(i = i - 1 ; i >= 0 ; i--) {
			System.out.print(arr[i]);
		}
	}
	
	// chuyển về hệ 10 -> lấy từng giá trị của từng vị trí x 2 ^ 
	// Math.pow(2, p) = 2^p
	public void convertDecimal(int n) {
		int decimal = 0 , p =  0;
		while( n > 0 ) {
			int temp = n % 10;
            decimal += temp*Math.pow(2, p);
            n = n /10;
            p++;
		}
		System.out.println(decimal);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bai02 object = new Bai02();
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập số thập phân: ");
		int n = sc.nextInt();
		object.convertBinary(n);
		System.out.println("\nNhập số nhị phân: ");
		int m = sc.nextInt();
		object.convertDecimal(m);
	}

}
