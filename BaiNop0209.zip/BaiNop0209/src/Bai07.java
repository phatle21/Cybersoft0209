import java.util.Scanner;

public class Bai07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập ước số: ");
		int n = sc.nextInt();
		while(n < 1) {
			System.out.println("Đề bài chỉ nhập số từ 1 trở lên , nhập lại : ");
			n = sc.nextInt();
		}
		// ước số là chia hết cho 1 và các số được nó chia hết  
		for(int i = 1 ; i <= n ; i++) {
			if(n % i == 0) {
				System.out.print(i + " ");
			}
		}
	}

}
